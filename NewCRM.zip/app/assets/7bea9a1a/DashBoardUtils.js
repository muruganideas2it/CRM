$(document).ready(function () {
    /**
     * For 
     */
    $.ajax({url: "/app/index.php/meetings/default/GetLastMonthMeetings",
        context: document.body,
        success: function (data) {
            $("#count_of_meetings").text(data);
        }});

    $.ajax({url: "/app/index.php/opportunities/default/GetoptFinalAmtTotalByStage",
        dataType: 'json',
        success: function (data) {
            $.each(data, function (key, value) {
                $.each(value, function (FieldNameType, TotalValue) {
                    var totFinalAmt = TotalValue.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
                    $("#totalFinalAmt").text('$' + totFinalAmt);
                })
            })

        }});

    $.ajax({url: "/app/index.php/agreements/default/GetLastAgmntAmountByStatus",
        dataType: 'json',
        success: function (data) {
            $.each(data, function (key, value) {
                $.each(value, function (AgmntType, AgmntValue) {
                    if (AgmntType == 'ProjectAgmnt') {
                        var ProAgmntValue = AgmntValue.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
                        $("#Total_Project_Amt").text('$' + ProAgmntValue);
                    }
                    if (AgmntType == 'RecurringAgmnt') {
                        var RecAgmntValue = AgmntValue.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
                        $("#Total_Rec_Amt").text('$' + RecAgmntValue);
                    }
                })

            })
        }});

    $.ajax({url: "/app/index.php/agreements/default/GetAllProjectAgmnts",
        success: function (data) {
            $("#CURRENT_GPM_YTD_VS_AGREEMENT_GPM_PRO").html(data);
        }
    });

    $.ajax({url: "/app/index.php/agreements/default/GetAllRecuringAgmnts",
        success: function (data) {
            $("#CURRENT_GPM_YTD_VS_AGREEMENT_GPM_REC").html(data);
        }
    });
    
    $.ajax({url: "/app/index.php/agreements/default/GetAllAgmntsForAgmntVsTracking",
        success: function (data) {
            $("#REVENUE_BY_MAN_HOUR_TRACKING_VS_AGREEMENT").html(data);
        }
    });

});